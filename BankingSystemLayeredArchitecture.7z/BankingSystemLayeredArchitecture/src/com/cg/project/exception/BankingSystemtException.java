package com.cg.project.exception;

public class BankingSystemtException {

}
